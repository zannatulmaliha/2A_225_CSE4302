#include <iostream>
#include "Product.h"
#include "random.cpp"
using namespace std;

void EditInformationByKeyboard(Product &p){
    string name,cat_name,des;
    int amount_p;
    float price;
    float disc;
    cout<<"Enter product name: ";
    cin>>name;
    cout<<"\nEnter product category: ";
    cin>>cat_name;
    cout<<"\nEnter description: ";
    getline(cin,des);
    cout<<"\nEnter amount: ";
    cin>>amount_p;
    cout<<"\nEnter price: ";
    cin>>price;
    cout<<"\nEnter discount:";
    cin>>disc;

    p.Setproduct_name(name);
    p.Setcategory_name(cat_name);
    p.Setdescription(des);
    p.Setamount(amount_p);
    p.Setregular_price(price);
    p.Setdiscount_rate(disc);
    p.increment_number();
}

void generateInformaiotnRandom(Product &p){
     string name,cat_name,des;
    int amount_p;
    float price;
    float disc;

    int namelen=randomInRange(3,7);
    name=srand()%namelen;
    p.Setproduct_name(name);

    cat_name=srand()%namelen;
    p.Setcategory_name(cat_name);

    p.Setamount()

}

int Product::number=0;
int main()
{
    cout << "Hello world!" << endl;
    Product p1[100];

    return 0;
}
