#include<iostream>
#include "Product.h"
#include<string>
using namespace std;

Product::Product()
{
    //ctor
}

Product::~Product()
{
    //dtor
}

string Product::Getproduct_name(){ return product_name; }
void Product::Setproduct_name(string val) { product_name = val; }
string Product::Getcategory_name() { return category_name; }
 void Product::Setcategory_name(string val) { category_name = val; }
string Product::Getdescription() { return description; }
void Product::Setdescription(string val) { description = val; }
int Product::Getamount() { return amount; }
void Product::Setamount(int val) { amount = val; }
float Product::Getregular_price() { return regular_price; }
void Product::Setregular_price(float val) { regular_price = val; }
float Product::Getdiscount_rate() { return discount_rate; }
void Product::Setdiscount_rate(float val) { discount_rate = val; }
int Product::get_number(){return number;}
void Product::increment_number(){number++;}
void Product::PurchaseProduct(int a){
    if(a<=amount){
        amount-=a;
        number-=a;
    }
    else
    cout<<"Cannot purchase\n";
}
void Product::RestockProduct (int a){
     amount+=a;
     number+=a;
}
double Product::calculateDiscount (int amountOfProducts){
      double discount=0;
      if(amountOfProducts>=5){
        discount=(discount_rate/100)*regular_price;
      }
      if(number>=10){
        discount+=(3/100)*regular_price;
      }
      return discount;
}
double Product::netTotal (int amountOfProducts){
    double ans=((regular_price*amount)-calculateDiscount(amountOfProducts));
    return ans;
}

