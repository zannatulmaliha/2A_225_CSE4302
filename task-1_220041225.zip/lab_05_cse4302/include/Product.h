#include<string>
using namespace std;

#ifndef PRODUCT_H
#define PRODUCT_H


class Product
{
    public:
        Product();
        virtual ~Product();
        string Getproduct_name();
        void Setproduct_name(string val);
        string Getcategory_name();
        void Setcategory_name(string val);
        string Getdescription();
        void Setdescription(string val);
        int Getamount();
        void Setamount(int val);
        float Getregular_price();
        void Setregular_price(float val);
        float Getdiscount_rate();
        void Setdiscount_rate(float val);
        void PurchaseProduct(int a);
        void RestockProduct (int a);
        double calculateDiscount (int amountOfProducts);
        double netTotal (int amountOfProducts);
        void increment_number();
        int get_number();
    protected:
    private:
        string product_name;
        string category_name;
        string description;
        int amount;
        float regular_price;
        float discount_rate;
        static int number;

};

#endif // PRODUCT_H
